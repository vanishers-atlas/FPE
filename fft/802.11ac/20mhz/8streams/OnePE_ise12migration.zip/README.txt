In this folder, place only the source required to configure the SPU to realise the 20MHz FFT for 802.11ac.

The source describing the SPU itself should not be included here.